# MathLib
A simple python math library

With MathLib, it's easy to operate with multiple numbers:

![add image](https://github.com/CaioVieiraF/MathLib/blob/master/media/Peek%202020-06-30%2013-15.gif)
